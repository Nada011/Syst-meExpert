from flask import Flask, render_template, redirect, url_for
from flask_wtf import FlaskForm
from wtforms import BooleanField, StringField, RadioField, SelectMultipleField, SubmitField
from wtforms.validators import DataRequired

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'  # Utilisé pour sécuriser les formulaires

class ParfumForm(FlaskForm):
    # Questions sur la personnalité
    personnalite= RadioField('Comment décririez-vous votre personnalité ?', choices=[
        ('Extravertie', 'Extravertie'),
        ('Introvertie', 'Introvertie'),
        ('Romantique', 'Romantique'),
        ('Audacieuse', 'Audacieuse'),
        ('Calme et réfléchie', 'Calme et réfléchie')], validators=[DataRequired()])

    ambiance = RadioField('Préférez-vous les ambiances suivantes ?', choices=[
        ('Dynamiques', 'Dynamiques'),
        ('Paisibles', 'Paisibles')], validators=[DataRequired()])

    tendance = RadioField('Préférez-vous les tendances suivantes ?', choices=[
        ('Classiques', 'Classiques'),
        ('Modernes', 'Modernes')], validators=[DataRequired()])

    cadre = RadioField('Vous sentez-vous plus à l’aise dans un cadre :', choices=[
        ('Naturel', 'Naturel'),
        ('Urbain', 'Urbain')], validators=[DataRequired()])

    # Genre et usage
    genre = RadioField('Quel est votre genre ?', choices=[
        ('Homme', 'Homme'),
        ('Femme', 'Femme'),
        ('Non-binaire', 'Non-binaire'),
        ('Préfère ne pas répondre', 'Préfère ne pas répondre')], validators=[DataRequired()])

    occasion = RadioField('À quelle occasion souhaitez-vous porter ce parfum ?',
                                  choices=[('Quotidien', 'Quotidien'),
                                           ('Travail', 'Travail'),
                                           ('Soirée', 'Soirée'),
                                           ('Rendez-vous romantique', 'Rendez-vous romantique'),
                                           ('Sport', 'Sport')])

    saison = RadioField('Recherchez-vous un parfum pour une saison spécifique ?', choices=[
        ('Printemps', 'Printemps'),
        ('Été', 'Été'),
        ('Automne', 'Automne'),
        ('Hiver', 'Hiver')])

    # Préférences olfactives
       # Sélection multiple avec BooleanField pour chaque option
  
    famille = RadioField('Avez-vous une note ou un ingrédient préféré ?',
        choices=[
        ('Floral', 'Floral'),
        ('Fruité', 'Fruité'),
        ('Boisé', 'Boisé'),
        ('Oriental', 'Oriental'),
        ('Frais', 'Frais'),
        ('Épicé', 'Épicé')],
        
        validators=[DataRequired()])
   

    #intensite = RadioField('Préférez-vous des parfums ?', choices=[
     #   ('Doux et subtils', 'Doux et subtils'),
      #  ('Puissants et marquants', 'Puissants et marquants')])

   

    # Budget et marque
    budget = RadioField('Quel est votre budget pour ce parfum ?', choices=[
        ('Moins de 50 €', 'Moins de 50 €'),
        ('50 € à 100 €', '50 € à 100 €'),
        ('Plus de 100 €', 'Plus de 100 €')], validators=[DataRequired()])

    marque = StringField('Avez-vous une marque préférée ?', validators=[DataRequired()])

   

    submit = SubmitField('Soumettre')

PARFUMS = [
    {"nom": "Chanel N°5", "famille": "Floral", "genre": "Femme", "occasion": "Soirée", "saison": "Hiver", 
     "budget": "Plus de 100 €", "marque": "Chanel", "tendance": "Classiques", "ambiance": "Paisibles", "cadre": "Urbain", "personnalite": "Romantique"},
    {"nom": "Bleu de Chanel", "famille": "Boisé", "genre": "Homme", "occasion": "Quotidien", "saison": "Printemps", 
     "budget": "50 € à 100 €", "marque": "Chanel", "tendance": "Modernes", "ambiance": "Dynamiques", "cadre": "Urbain", "personnalite": "Extravertie"},
    {"nom": "J'adore", "famille": "Floral", "genre": "Femme", "occasion": "Rendez-vous romantique", "saison": "Été", 
     "budget": "Plus de 100 €", "marque": "Dior", "tendance": "Classiques", "ambiance": "Paisibles", "cadre": "Naturel", "personnalite": "Romantique"},
    {"nom": "La Vie Est Belle", "famille": "Gourmand", "genre": "Femme", "occasion": "Quotidien", "saison": "Automne", 
     "budget": "50 € à 100 €", "marque": "Lancôme", "tendance": "Classiques", "ambiance": "Paisibles", "cadre": "Naturel", "personnalite": "Calme et réfléchie"},
    {"nom": "Dior Sauvage", "famille": "Épicé", "genre": "Homme", "occasion": "Travail", "saison": "Hiver", 
     "budget": "Plus de 100 €", "marque": "Dior", "tendance": "Modernes", "ambiance": "Dynamiques", "cadre": "Urbain", "personnalite": "Audacieuse"},
    {"nom": "Acqua di Giò", "famille": "Aquatique", "genre": "Homme", "occasion": "Quotidien", "saison": "Été", 
     "budget": "50 € à 100 €", "marque": "Giorgio Armani", "tendance": "Modernes", "ambiance": "Dynamiques", "cadre": "Naturel", "personnalite": "Extravertie"},
    {"nom": "Black Opium", "famille": "Oriental", "genre": "Femme", "occasion": "Soirée", "saison": "Hiver", 
     "budget": "Plus de 100 €", "marque": "Yves Saint Laurent", "tendance": "Classiques", "ambiance": "Paisibles", "cadre": "Urbain", "personnalite": "Romantique"},
    {"nom": "Terre d'Hermès", "famille": "Boisé", "genre": "Homme", "occasion": "Travail", "saison": "Automne", 
     "budget": "Plus de 100 €", "marque": "Hermès", "tendance": "Classiques", "ambiance": "Paisibles", "cadre": "Naturel", "personnalite": "Calme et réfléchie"},
    {"nom": "Flowerbomb", "famille": "Floral", "genre": "Femme", "occasion": "Soirée", "saison": "Hiver", 
     "budget": "Plus de 100 €", "marque": "Viktor & Rolf", "tendance": "Modernes", "ambiance": "Dynamiques", "cadre": "Urbain", "personnalite": "Audacieuse"},
    {"nom": "Tom Ford Noir", "famille": "Oriental", "genre": "Homme", "occasion": "Soirée", "saison": "Automne", 
     "budget": "Plus de 100 €", "marque": "Tom Ford", "tendance": "Modernes", "ambiance": "Dynamiques", "cadre": "Urbain", "personnalite": "Extravertie"},
    {"nom": "One Million", "famille": "Oriental", "genre": "Homme", "occasion": "Soirée", "saison": "Hiver", 
     "budget": "50 € à 100 €", "marque": "Paco Rabanne", "tendance": "Modernes", "ambiance": "Dynamiques", "cadre": "Urbain", "personnalite": "Extravertie"},
    {"nom": "Miss Dior", "famille": "Floral", "genre": "Femme", "occasion": "Rendez-vous romantique", "saison": "Printemps", 
     "budget": "Plus de 100 €", "marque": "Dior", "tendance": "Classiques", "ambiance": "Paisibles", "cadre": "Naturel", "personnalite": "Romantique"},
    {"nom": "Le Male", "famille": "Fougère", "genre": "Homme", "occasion": "Quotidien", "saison": "Hiver", 
     "budget": "50 € à 100 €", "marque": "Jean Paul Gaultier", "tendance": "Classiques", "ambiance": "Paisibles", "cadre": "Urbain", "personnalite": "Introvertie"},
    {"nom": "Invictus", "famille": "Aromatique", "genre": "Homme", "occasion": "Sport", "saison": "Été", 
     "budget": "50 € à 100 €", "marque": "Paco Rabanne", "tendance": "Modernes", "ambiance": "Dynamiques", "cadre": "Naturel", "personnalite": "Audacieuse"},
    {"nom": "Baccarat Rouge 540", "famille": "Oriental", "genre": "Unisexe", "occasion": "Soirée", "saison": "Automne", 
     "budget": "Plus de 100 €", "marque": "Maison Francis Kurkdjian", "tendance": "Modernes", "ambiance": "Paisibles", "cadre": "Urbain", "personnalite": "Calme et réfléchie"}
]
#def recommander_parfum(form_data):if (
        #form_data['famille'].strip().lower() == "Floral".lower() and
        #form_data['genre'].strip().lower() == "Femme".lower() and
        #form_data['occasion'].strip().lower() == "Soirée".lower() and
        #form_data['saison'].strip().lower() == "Hiver".lower() and
        #form_data['budget'].strip().lower()== "Plus de 100 €".lower() and
        #form_data['marque'].strip().lower() == "Chanel".lower() and
        #form_data['tendance'].strip().lower() == "Classiques".lower()and
        #form_data['ambiance'].strip().lower()== "Paisibles".lower() and
        #form_data['cadre'].strip().lower() == "Urbain".lower() and
       # form_data['personnalite'].strip().lower() == "Romantique".lower()
   # ):
       # return "Chanel N°5"
def recommander_parfum(form_data):
    resultats = [
        parfum["nom"] 
        for parfum in PARFUMS # type: ignore
        if all(parfum[key].lower() == value.strip().lower() for key, value in form_data.items())
    ]
    return resultats if resultats else ["Aucun parfum correspondant n'a été trouvé."]

@app.route('/', methods=['GET', 'POST'])
def index():
    form = ParfumForm()
    if form.validate_on_submit():
        form_data = {
            'famille': form.famille.data,
            'genre': form.genre.data,
            'occasion': form.occasion.data,
            'saison': form.saison.data,
            'budget': form.budget.data,
            'marque': form.marque.data,
            'tendance': form.tendance.data,
            'ambiance': form.ambiance.data,
            'cadre': form.cadre.data,
            'personnalite': form.personnalite.data,
        }
        print(form_data)

        recommended_perfum = recommander_parfum(form_data)
        print(recommended_perfum)
        return render_template('result.html', recommandations=[recommended_perfum])
    return render_template('form.html', form=form)

if __name__ == '__main__':
    app.run(debug=True)